"""Hardware protocol helpers."""
