"""BMC protocol helpers."""
